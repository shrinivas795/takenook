from django.http import HttpResponse
from django.shortcuts import render
from polls.models import student

def index(request):
    if request.method == 'POST':
        name = request.POST['name']
        marks  = request.POST['marks']

        stud = student()
        stud.name = name
        stud.marks = marks
        stud.save()
    return render(request, "polls/index.html")  